EDITH ULTRA CEREBRO — IA LOCAL

1) Instala Ollama en el equipo y descarga un modelo local, por ejemplo llama3.2.
2) Inicia Ollama.
3) Ejecuta iniciar_edith_ultra.sh (macOS/Linux) o: python3 edith_ultra_brain.py
4) Abre http://127.0.0.1:8765/EDITH.html

El navegador habla con EDITH por /api/local-ai y el servidor habla con Ollama en 127.0.0.1:11434.
La memoria persistente se guarda en edith_memory.json.
No se incluye ninguna API key.

Nota: este proyecto no contiene ni replica el modelo propietario de OpenAI. La inteligencia abierta depende del modelo local instalado en Ollama. Puedes cambiar el modelo con EDITH_MODEL=nombre_del_modelo.

CONTROL SEGURO DEL PC
- EDITH puede crear alarmas locales en edith_schedule.json.
- Puede abrir aplicaciones de una lista permitida.
- No ejecuta comandos arbitrarios, no borra archivos y no instala software.
- El resumen de correo requiere una conexión autorizada a un proveedor de correo; el cerebro local no obtiene correos por sí solo.


MODO CEREBRO TOTAL
- EDITH envía cada frase hablada al cerebro local, no solo comandos de menú.
- Mantiene historial conversacional persistente y memoria explícita ("recuerda que...").
- Puede analizar preguntas, explicarlas, continuar conversaciones y responder en español.
- Las funciones/modos existentes siguen pudiendo ejecutarse por voz; después EDITH puede confirmar la acción.
- La memoria principal se guarda en edith_memory.json y una copia de contexto reciente en el navegador.
- Para respuestas abiertas se requiere Ollama + un modelo local configurado.


CEREBRO OPENAI: esta versión usa OpenAI Responses API mediante OPENAI_API_KEY. La clave se mantiene exclusivamente en el servidor local. Modelo configurable con EDITH_OPENAI_MODEL.
