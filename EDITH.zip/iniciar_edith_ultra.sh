#!/bin/sh
cd "$(dirname "$0")"
python3 edith_ultra_brain.py
