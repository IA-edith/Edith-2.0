#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$BASE"
"$BASE/edith_start_unificado.sh" >/tmp/edith_brain.log 2>&1 &
BRAIN_PID=$!
trap 'kill "$BRAIN_PID" 2>/dev/null || true' EXIT
for i in {1..30}; do
  if curl -fsS http://127.0.0.1:8765/api/brain-status >/tmp/edith_brain_status.json 2>/dev/null; then break; fi
  sleep 1
done
if command -v chromium >/dev/null 2>&1; then BROWSER=chromium
elif command -v chromium-browser >/dev/null 2>&1; then BROWSER=chromium-browser
else echo "Instala Chromium."; exit 1; fi
exec "$BROWSER" --kiosk --start-fullscreen --autoplay-policy=no-user-gesture-required http://127.0.0.1:8765/EDITH.html
