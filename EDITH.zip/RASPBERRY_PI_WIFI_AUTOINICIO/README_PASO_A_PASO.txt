EDITH DEFINITIVA — Raspberry Pi SIN ETHERNET

HARDWARE:
- Raspberry Pi 5 (recomendado)
- microSD
- Fuente
- HDMI + pantalla
- Wi-Fi
- Micrófono
- Cámara (opcional)

CONFIGURACIÓN:
1. Instala Raspberry Pi OS.
2. Durante el primer arranque, conecta la Raspberry a tu Wi-Fi desde el escritorio.
3. Copia la carpeta completa de EDITH a /home/pi/EDITH.
4. El objetivo es que el lanzador se ejecute al iniciar sesión.
5. Chromium se abre en modo pantalla completa y carga EDITH desde la propia Raspberry.

USO DIARIO:
ENCENDER → Wi-Fi → EDITH → LISTA.

NO HACE FALTA ETHERNET.

NOTA:
El primer ajuste de autoinicio es una configuración del sistema operativo. Una vez hecho, no hay que abrir EDITH manualmente.
