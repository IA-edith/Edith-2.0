# EDITH DEFINITIVA — Raspberry Pi / Wi‑Fi / Inicio automático

## Objetivo
Al encender la Raspberry Pi:
1. Raspberry Pi OS inicia.
2. Se conecta a la red Wi‑Fi configurada.
3. EDITH se abre automáticamente en pantalla completa.
4. No hace falta abrir el navegador manualmente.

## Importante
Esta carpeta contiene los archivos necesarios para preparar el inicio automático.
La primera configuración de Raspberry Pi OS sí requiere una configuración inicial del sistema.
Después de dejar configurado el inicio automático, el uso diario es simplemente encender la Raspberry.

## Wi‑Fi
No se requiere Ethernet. Configura la red Wi‑Fi desde el menú gráfico de Raspberry Pi OS durante la primera puesta en marcha.

## Cámara y micrófono
Conecta cámara y micrófono USB antes de encenderla para que EDITH pueda solicitar los permisos del navegador.

## Ruta esperada
La carpeta completa de EDITH debe estar copiada en:
`/home/pi/EDITH`

Si el usuario de Raspberry Pi no se llama `pi`, usa la carpeta personal del usuario que haya creado Raspberry Pi OS.

## Inicio automático
El archivo `iniciar_edith_wifi.sh` levanta un servidor local y abre EDITH en Chromium en modo kiosco.

El archivo `edith-definitiva-wifi.service` está preparado como servicio de inicio automático.

Para la activación final del servicio se necesita una única configuración del sistema. Si se quiere evitar completamente la terminal, puede hacerse desde una herramienta gráfica de servicios/autostart de Raspberry Pi OS.
