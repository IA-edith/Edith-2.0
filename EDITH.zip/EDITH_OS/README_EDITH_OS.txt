EDITH OS — Raspberry Pi

Sistema dedicado: ENCENDER → EDITH OS → EDITH.
Wi-Fi, sin Ethernet; arranque automático; interfaz a pantalla completa; escritorio normal oculto durante el uso.

Instalación inicial: Raspberry Pi OS 64-bit + Wi-Fi. Copia el proyecto a /home/pi/EDITH y coloca edith-os.desktop en /home/pi/.config/autostart/. Reinicia.

Esto es un EDITH OS dedicado sobre Linux/Raspberry Pi OS: Linux sigue siendo la base, pero EDITH es la interfaz principal del dispositivo.
