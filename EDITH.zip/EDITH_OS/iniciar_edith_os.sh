#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$BASE"
"$BASE/edith_start_unificado.sh" >/tmp/edith_brain.log 2>&1 &
BRAIN_PID=$!
trap 'kill "$BRAIN_PID" 2>/dev/null || true' EXIT
for i in {1..30}; do curl -fsS http://127.0.0.1:8765/api/brain-status >/dev/null 2>&1 && break; sleep 1; done
while true; do
  if command -v chromium >/dev/null 2>&1; then chromium --kiosk --start-fullscreen --noerrdialogs --disable-session-crashed-bubble --disable-infobars --autoplay-policy=no-user-gesture-required http://127.0.0.1:8765/EDITH.html
  elif command -v chromium-browser >/dev/null 2>&1; then chromium-browser --kiosk --start-fullscreen --noerrdialogs --disable-session-crashed-bubble --disable-infobars --autoplay-policy=no-user-gesture-required http://127.0.0.1:8765/EDITH.html
  else exit 1; fi
  sleep 2
done
