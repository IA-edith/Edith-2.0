#!/usr/bin/env python3
import os, re, math, json, subprocess, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'edith_prints'; OUT.mkdir(exist_ok=True)
OLLAMA=os.environ.get('EDITH_OLLAMA_URL','http://127.0.0.1:11434/api/chat')
MODEL=os.environ.get('EDITH_MODEL','llama3.2')


def _slug(s):
    s=re.sub(r'[^a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ_-]+','_',s).strip('_')
    return (s or 'edith_model')[:70]

def _num(text, default):
    m=re.search(r'(\d+(?:[.,]\d+)?)\s*(?:mm|milimetros|milímetros)?', text, re.I)
    return float(m.group(1).replace(',','.')) if m else default

def cube_stl(name, x,y,z):
    x,y,z=x/2,y/2,z
    v=[(-x,-y,0),(x,-y,0),(x,y,0),(-x,y,0),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
    f=[(0,1,2),(0,2,3),(4,6,5),(4,7,6),(0,4,5),(0,5,1),(1,5,6),(1,6,2),(2,6,7),(2,7,3),(3,7,4),(3,4,0)]
    return _stl(name,v,f)

def cyl_stl(name,r,h,n=48):
    vs=[]
    for z in (0,h):
        for i in range(n):
            a=2*math.pi*i/n; vs.append((r*math.cos(a),r*math.sin(a),z))
    vs += [(0,0,0),(0,0,h)]
    f=[]
    for i in range(n):
        j=(i+1)%n; f += [(i,j,n+j),(i,n+j,n+i),(2*n,i,j),(2*n+1,n+j,n+i)]
    return _stl(name,vs,f)

def sphere_stl(name,r,seg=24,rings=12):
    vs=[]
    for j in range(rings+1):
        ph=math.pi*j/rings
        for i in range(seg):
            th=2*math.pi*i/seg; vs.append((r*math.sin(ph)*math.cos(th),r*math.sin(ph)*math.sin(th),r*math.cos(ph)+r))
    f=[]
    for j in range(rings):
        for i in range(seg):
            a=j*seg+i;b=j*seg+(i+1)%seg;c=(j+1)*seg+(i+1)%seg;d=(j+1)*seg+i
            if j: f.append((a,b,d))
            if j<rings-1: f.append((b,c,d))
    return _stl(name,vs,f)

def _stl(name,vs,fs):
    def facet(a,b,c):
        ax,ay,az=vs[a]; bx,by,bz=vs[b]; cx,cy,cz=vs[c]
        ux,uy,uz=bx-ax,by-ay,bz-az; vx,vy,vz=cx-ax,cy-ay,cz-az
        nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
        ln=math.sqrt(nx*nx+ny*ny+nz*nz) or 1; nx/=ln;ny/=ln;nz/=ln
        return f'  facet normal {nx:.6g} {ny:.6g} {nz:.6g}\n    outer loop\n      vertex {ax:.6g} {ay:.6g} {az:.6g}\n      vertex {bx:.6g} {by:.6g} {bz:.6g}\n      vertex {cx:.6g} {cy:.6g} {cz:.6g}\n    endloop\n  endfacet\n'
    return 'solid '+_slug(name)+'\n'+''.join(facet(*q) for q in fs)+'endsolid '+_slug(name)+'\n'

def primitive_model(desc,name):
    t=desc.lower()
    if 'cubo' in t or 'caja' in t or 'cube' in t:
        nums=re.findall(r'(\d+(?:[.,]\d+)?)',t)
        a=[float(x.replace(',','.')) for x in nums[:3]]
        while len(a)<3:a.append(a[-1] if a else 20)
        return cube_stl(name,*a[:3])
    if 'cilindro' in t or 'cylinder' in t:
        nums=re.findall(r'(\d+(?:[.,]\d+)?)',t); a=[float(x.replace(',','.')) for x in nums]
        r=a[0]/2 if a else 10; h=a[1] if len(a)>1 else 20
        return cyl_stl(name,r,h)
    if 'esfera' in t or 'bola' in t or 'sphere' in t:
        return sphere_stl(name,_num(t,15))
    return None

def ollama(prompt):
    body={'model':MODEL,'messages':[{'role':'system','content':'Genera solo código OpenSCAD válido. Unidades en mm. No uses include, use, import, surface, file(), system() ni rutas externas. El resultado debe ser un modelo sólido imprimible 3D.'},{role:'user','content':prompt}], 'stream':False}
    req=urllib.request.Request(OLLAMA,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=45) as r:
        j=json.loads(r.read())
    return j.get('message',{}).get('content','')

def clean_scad(code):
    code=re.sub(r'```(?:openscad)?','',code,flags=re.I).replace('```','').strip()
    if any(x in code.lower() for x in ['include',' use ','import(','surface(','file(','system(']):
        raise ValueError('OpenSCAD generado contiene una instrucción no permitida')
    return code

def make_3d(desc):
    name=_slug(desc)
    stl=primitive_model(desc,name)
    scad=None
    if stl is None:
        try: scad=clean_scad(ollama(desc))
        except Exception as e: raise RuntimeError('No pude generar un modelo arbitrario. Se necesita Ollama local activo: '+str(e))
        scad_path=OUT/(name+'.scad'); scad_path.write_text(scad,encoding='utf-8')
        openscad=next((x for x in ['openscad','/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD'] if os.path.exists(x) or subprocess.call(['bash','-lc',f'command -v {x} >/dev/null 2>&1'])==0),None)
        if openscad:
            out=OUT/(name+'.stl'); subprocess.run([openscad,'-o',str(out),str(scad_path)],check=True,timeout=90,capture_output=True); return out
        return scad_path
    out=OUT/(name+'.stl'); out.write_text(stl,encoding='utf-8'); return out

def make_2d(desc):
    name=_slug(desc)
    t=desc.lower(); size=_num(t,100)
    if 'circulo' in t or 'círculo' in t: body=f'<circle cx="50" cy="50" r="40" fill="none" stroke="black" stroke-width="2"/>'
    elif 'cuadrado' in t: body='<rect x="10" y="10" width="80" height="80" fill="none" stroke="black" stroke-width="2"/>'
    elif 'rectangulo' in t or 'rectángulo' in t: body='<rect x="10" y="25" width="80" height="50" fill="none" stroke="black" stroke-width="2"/>'
    elif 'estrella' in t: body='<polygon points="50,8 61,38 94,38 67,57 77,90 50,70 23,90 33,57 6,38 39,38" fill="none" stroke="black" stroke-width="2"/>'
    else:
        body=f'<text x="50" y="52" text-anchor="middle" font-family="Arial" font-size="8">{_slug(desc).replace("_"," ")}</text>'
    svg=f'<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="{size}mm" height="{size}mm" viewBox="0 0 100 100">{body}</svg>\n'
    out=OUT/(name+'.svg'); out.write_text(svg,encoding='utf-8')
    # optional PNG conversion if cairosvg exists
    try:
        import cairosvg; cairosvg.svg2png(bytestring=svg.encode(),write_to=str(OUT/(name+'.png')),output_width=1200,output_height=1200)
    except Exception: pass
    return out
