EDITH DEFINITIVA
================

Esta es la compilación maestra del proyecto EDITH.

Entrada principal:
  EDITH.html

Incluye la integración principal de:
- Cerebro local y memoria
- Diccionario offline y aprendizaje de palabras
- Comandos personalizados por voz
- Voz original humanizada de EDITH
- Reconocimiento/comandos de voz
- Modos EDITH y modos de cámara/GPS
- Sistemas Homecoming / Far From Home y menú de telarañas en las manos
- Modo aventura
- Caminata, sigilo, nocturno, retro, juego, noticia, gadget, poder cósmico y estudio
- Gaming, Fortnite, Nintendo, PS5, Xbox y Hacker seguro
- Misiones y árbol de habilidades
- Laboratorio de impresión 2D/3D
- Control de PC con acciones permitidas y agenda local
- Sistemas 36–135 como subsistema incluido
- Puente local PS5
- Archivos opcionales para Raspberry Pi

IMPORTANTE
- La voz es un perfil original y humanizado; no clona la voz de una persona real.
- El control del sistema operativo no ejecuta órdenes arbitrarias peligrosas.
- La integración de servicios externos depende de sus permisos/conexiones.
- Para impresión 3D, el flujo genera archivos que después deben pasar por un slicer.
