EDITH OFFLINE - CORRECCIÓN DEL CARGADOR 0%

Se corrigió el bloqueo visual del cargador circular al 0%.
La causa era que el HTML intentaba crear MediaPipe Hands y Camera aunque los archivos locales offline no estaban incluidos.

Ahora:
- EDITH no queda congelada en 0% si faltan esos archivos.
- La cámara puede continuar funcionando.
- La voz puede iniciar aunque falte el modelo de manos.
- Si los modelos de manos locales están instalados, el sistema los utilizará.

Nota: para reconocimiento de manos 100% offline todavía deben estar presentes los archivos locales de MediaPipe Hands dentro de offline-mp/.
