const CACHE='edith-offline-v1';
const REMOTE={
  './offline-mp/camera_utils.js':'https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js',
  './offline-mp/drawing_utils.js':'https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js',
  './offline-mp/hands.js':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js',
  './offline-tf/tf.min.js':'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.20.0/dist/tf.min.js',
  './offline-coco/coco-ssd.min.js':'https://cdn.jsdelivr.net/npm/@tensorflow-models/coco-ssd@2.2.3/dist/coco-ssd.min.js',
  './offline-tesseract/tesseract.min.js':'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js',
  './offline-mp/hands_solution_packed_assets.data':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands_solution_packed_assets.data',
  './offline-mp/hands_solution_packed_assets_loader.js':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands_solution_packed_assets_loader.js',
  './offline-mp/hands_solution_simd_wasm_bin.js':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands_solution_simd_wasm_bin.js',
  './offline-mp/hands_solution_simd_wasm_bin.wasm':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands_solution_simd_wasm_bin.wasm',
  './offline-mp/hands_solution_wasm_bin.js':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands_solution_wasm_bin.js',
  './offline-mp/hands_solution_wasm_bin.wasm':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands_solution_wasm_bin.wasm',
  './offline-mp/hands.binarypb':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.binarypb',
  './offline-mp/hand_landmark_lite.tflite':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hand_landmark_lite.tflite',
  './offline-mp/hand_landmark_full.tflite':'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hand_landmark_full.tflite'
};
self.addEventListener('install',e=>{
  e.waitUntil((async()=>{
    const c=await caches.open(CACHE);
    for(const [local,remote] of Object.entries(REMOTE)){
      try{const r=await fetch(remote,{mode:'cors'}); if(r.ok) await c.put(new Request(new URL(local,self.location.href)),r.clone());}catch(err){}
    }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(REMOTE[u.pathname.replace(/^\//,'./')]){
    e.respondWith((async()=>{
      const c=await caches.open(CACHE); const hit=await c.match(e.request); if(hit)return hit;
      const remote=REMOTE[u.pathname.replace(/^\//,'./')];
      try{const r=await fetch(remote,{mode:'cors'}); if(r.ok) await c.put(e.request,r.clone()); return r;}catch(err){return new Response('',{status:503});}
    })());
    return;
  }
  e.respondWith((async()=>{
    const c=await caches.open(CACHE); const hit=await c.match(e.request); if(hit)return hit;
    try{return await fetch(e.request);}catch(err){return hit||Response.error();}
  })());
});
