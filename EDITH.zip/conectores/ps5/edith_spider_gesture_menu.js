(function(){
  const STYLE_ID='edith-spider-double-menu-style';
  const ROOT_ID='edith-spider-double-menu';
  const MODES=[
    ['HOME · TRAINING WHEELS','Protocolo de entrenamiento / bloqueo de funciones avanzadas'],
    ['HOME · RECON AVANZADO','Enhanced Reconnaissance Mode'],
    ['HOME · COMBATE AUMENTADO','Enhanced Combat Mode'],
    ['HOME · INSTANT KILL','Protocolo de combate ficticio · solo simulación'],
    ['HOME · RAPID FIRE','Disparo rápido de telaraña'],
    ['HOME · WEB SELECT','Selector de configuraciones de lanzaredes'],
    ['HOME · TASER WEB','Configuración eléctrica ficticia de telaraña'],
    ['HOME · WEB GRENADE','Configuración de telaraña tipo granada · simulación'],
    ['HOME · SPLITTER WEB','Configuración de telaraña múltiple'],
    ['HOME · RICOCHET WEB','Configuración de telaraña rebotante'],
    ['HOME · DAMPERS','Amortiguadores del lanzaredes'],
    ['HOME · BABY MONITOR','Registro y análisis de sesión'],
    ['HOME · HUD / AR','Interfaz holográfica y realidad aumentada'],
    ['HOME · TRACKING','Rastreo de objetivos y Spider-Tracers'],
    ['HOME · GPS','Navegación y localización'],
    ['HOME · LISTENING','Escucha / reconocimiento avanzado'],
    ['HOME · DIAGNOSTICS','Diagnóstico del traje'],
    ['HOME · DATABASE','Base de datos y análisis contextual'],
    ['HOME · SPIDER-SIGNAL','Proyección holográfica de señal'],
    ['HOME · RECON DRONE','Interfaz del dron de reconocimiento'],
    ['HOME · NAVIGATION','Ruta / interceptación / asistencia'],
    ['HOME · EMERGENCY DESCENT','Paracaídas y descenso de emergencia'],
    ['HOME · WEB-WINGS','Planeo / alas de telaraña'],
    ['HOME · ILLUMINATION','Iluminación integrada'],
    ['HOME · SUIT VOICE AI','Asistente de voz del traje'],
    ['FFH · STARK SUIT','Traje Stark'],
    ['FFH · STEALTH SUIT','Traje sigiloso / Night Monkey'],
    ['FFH · UPGRADED SUIT','Traje mejorado rojo/negro'],
    ['FFH · IRON SPIDER','Configuración Iron Spider'],
    ['FFH · EDITH','Interfaz EDITH'],
    ['FFH · SATELLITE LINK','Enlace ficticio con sistemas EDITH'],
    ['FFH · DRONE CONTROL','Interfaz de drones EDITH · simulación'],
    ['FFH · HOLOGRAPHIC HUD','HUD holográfico del traje'],
    ['FFH · SPIDER-TRACERS','Rastreo mediante Spider-Tracers'],
    ['FFH · WEB-WINGS','Planeo / asistencia de vuelo'],
    ['FFH · 576 WEB SYSTEM','Catálogo de 576 combinaciones de lanzaredes'],
    ['FFH · SUIT ANALYSIS','Análisis y diagnóstico del traje'],
    ['FFH · COMMUNICATION','Comunicaciones del traje'],
    ['FFH · LOCATION','GPS / localización'],
    ['FFH · EMERGENCY','Protocolos de emergencia'],
    ['FFH · VOICE CONTROL','Control por voz EDITH']
  ];
  const PER_PAGE=9;
  let page=0, opened=false, lastSpider=false, spiderCount=0, lastGestureAt=0, candidate=-1, holdStart=0, raf=0;
  const $=id=>document.getElementById(id);
  function addStyle(){if($(STYLE_ID))return;const s=document.createElement('style');s.id=STYLE_ID;s.textContent=`
#${ROOT_ID}{position:fixed;inset:0;z-index:100500;display:none;pointer-events:none;font-family:Inter,system-ui,sans-serif;color:#e9fbff}
#${ROOT_ID}.open{display:block}
.edsm-back{position:absolute;inset:0;background:radial-gradient(circle at 50% 42%,rgba(50,190,255,.10),rgba(1,6,12,.84) 68%);backdrop-filter:blur(5px)}
.edsm-panel{position:absolute;left:50%;top:7%;transform:translateX(-50%);width:min(1180px,92vw);height:min(760px,86vh);border:1px solid rgba(100,220,255,.55);background:linear-gradient(135deg,rgba(3,15,24,.94),rgba(5,8,15,.90));box-shadow:0 0 70px rgba(0,210,255,.14),inset 0 0 40px rgba(0,180,255,.05);padding:18px;box-sizing:border-box;pointer-events:none;overflow:hidden}
.edsm-head{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(100,220,255,.2);padding-bottom:12px}.edsm-title{font-size:22px;letter-spacing:4px}.edsm-sub{font-size:9px;opacity:.65;letter-spacing:2px;margin-top:5px}.edsm-page{font:700 12px monospace;color:#7feaff}
.edsm-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}.edsm-card{min-height:88px;border:1px solid rgba(100,220,255,.20);background:rgba(255,255,255,.025);padding:12px;position:relative}.edsm-num{font:700 10px monospace;color:#65dcff}.edsm-name{font-size:13px;letter-spacing:1.2px;margin-top:7px}.edsm-desc{font-size:10px;opacity:.6;margin-top:5px}.edsm-card.active{border-color:#fff;box-shadow:0 0 24px rgba(90,220,255,.28);background:rgba(40,170,230,.12)}
.edsm-footer{position:absolute;left:18px;right:18px;bottom:14px;border-top:1px solid rgba(100,220,255,.18);padding-top:10px;display:flex;justify-content:space-between;font:700 10px monospace;opacity:.78}.edsm-gesture{color:#bdf7ff}.edsm-status{color:#7feaff}.edsm-hint{position:absolute;left:50%;bottom:3%;transform:translateX(-50%);font:700 10px monospace;letter-spacing:1.5px;padding:8px 12px;border:1px solid rgba(100,220,255,.35);background:rgba(0,10,17,.75)}
@media(max-width:700px){.edsm-grid{grid-template-columns:1fr}.edsm-panel{height:90vh}.edsm-title{font-size:16px}}
`;document.head.appendChild(s)}
  function addRoot(){if($(ROOT_ID))return;const r=document.createElement('div');r.id=ROOT_ID;r.innerHTML=`<div class="edsm-back"></div><div class="edsm-panel"><div class="edsm-head"><div><div class="edsm-title">◈ SPIDER-MAN SUIT INTERFACE</div><div class="edsm-sub">HOMEcoming + FAR FROM HOME · CONTROL POR GESTOS</div></div><div class="edsm-page" id="edsm-page"></div></div><div class="edsm-grid" id="edsm-grid"></div><div class="edsm-footer"><span class="edsm-gesture" id="edsm-gesture">ESPERANDO GESTO ARÁCNIDO ×2</span><span class="edsm-status" id="edsm-status">INTERFAZ CERRADA</span></div></div><div class="edsm-hint" id="edsm-hint">HAZ EL GESTO DE SPIDER-MAN DOS VECES PARA ABRIR</div>`;document.body.appendChild(r)}
  function say(t){try{if(window.speechSynthesis){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='es-ES';u.rate=.95;speechSynthesis.speak(u)}}catch(e){}}
  function render(){const start=page*PER_PAGE,end=Math.min(MODES.length,start+PER_PAGE),arr=MODES.slice(start,end);const grid=$('edsm-grid');if(!grid)return;grid.innerHTML=arr.map((m,i)=>`<div class="edsm-card" data-slot="${i}"><div class="edsm-num">${String(start+i+1).padStart(2,'0')}</div><div class="edsm-name">${m[0]}</div><div class="edsm-desc">${m[1]}</div></div>`).join('');if(end<MODES.length)grid.innerHTML+=`<div class="edsm-card" data-slot="9"><div class="edsm-num">10 · CONTINUAR</div><div class="edsm-name">CONTINUAR</div><div class="edsm-desc">Siguiente bloque de 9 modos</div></div>`;else grid.innerHTML+=`<div class="edsm-card" data-slot="9"><div class="edsm-num">10 · FINALIZAR</div><div class="edsm-name">VOLVER A EDITH</div><div class="edsm-desc">Cerrar el menú Spider-Man</div></div>`;$('edsm-page').textContent=`BLOQUE ${page+1} · ${start+1}-${end} / ${MODES.length}`;candidate=-1}
  function open(){addStyle();addRoot();opened=true;page=0;render();$(ROOT_ID).classList.add('open');$('edsm-status').textContent='INTERFAZ ABIERTA';$('edsm-gesture').textContent='MANOS DETECTADAS · SELECCIONA 1–9';$('edsm-hint').textContent='MUEVE UN DEDO PARA MARCAR · MANTÉN 0.8s PARA EJECUTAR';say('Interfaz del traje Spider-Man activada')}
  function close(){if($(ROOT_ID))$(ROOT_ID).classList.remove('open');opened=false;candidate=-1;holdStart=0;if(raf)cancelAnimationFrame(raf);$('edsm-status')?.replaceChildren(document.createTextNode('INTERFAZ CERRADA'));$('edsm-hint')?.replaceChildren(document.createTextNode('HAZ EL GESTO DE SPIDER-MAN DOS VECES PARA ABRIR'));}
  function spiderPose(lm){
    const d=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
    const w=lm[0];
    const extended=(tip,pip)=>d(w,lm[tip])>d(w,lm[pip])*1.12;
    const index=extended(8,6), middle=!extended(12,10), ring=!extended(16,14), pinky=extended(20,18);
    // Classic web-shooter pose: index + little extended, middle/ring curled.
    return index&&middle&&ring&&pinky;
  }
  function selectSlot(slot){if(slot<0)return;const start=page*PER_PAGE;if(slot===9){if(start+PER_PAGE<MODES.length){page++;render();say('Continuar. Siguiente bloque de nueve modos.');}else{close();say('Menú Spider-Man cerrado.');}return;}const idx=start+slot;if(idx>=MODES.length)return;const m=MODES[idx];$('edsm-status').textContent='SELECCIONADO · '+m[0];say(m[0].replace(/·/g,','));if(idx===35 && window.EDITH576)window.EDITH576.open();if(idx===35 && window.EDITH_FFH)window.EDITH_FFH.open();}
  function mark(slot){document.querySelectorAll('#'+ROOT_ID+' .edsm-card').forEach(c=>c.classList.toggle('active',Number(c.dataset.slot)===slot));if(slot>=0){$('edsm-gesture').textContent='SELECCIÓN · '+(slot===9?'CONTINUAR':'SLOT '+(page*9+slot+1));}}
  function process(results){const found=results?.multiHandLandmarks||[];let isSpider=found.length>=2 && spiderPose(found[0]) && spiderPose(found[1]);const now=performance.now();if(isSpider&&!lastSpider){if(now-lastGestureAt<1800){spiderCount++;}else{spiderCount=1}lastGestureAt=now;if(spiderCount>=2&&!opened){open();spiderCount=0;}}lastSpider=isSpider;if(opened){if(isSpider){mark(-1);$('edsm-gesture').textContent='GESTO ARÁCNIDO · MENÚ ABIERTO';candidate=-1;holdStart=0;return;}let best={slot:-1,score:0};found.slice(0,2).forEach((lm,h)=>{const tips=[4,8,12,16,20],pips=[3,6,10,14,18];tips.forEach((tip,f)=>{const d1=Math.hypot(lm[0].x-lm[tip].x,lm[0].y-lm[tip].y);const d2=Math.hypot(lm[0].x-lm[pips[f]].x,lm[0].y-lm[pips[f]].y);const ratio=d1/Math.max(.001,d2);if(ratio>1.16&&ratio>best.score)best={slot:h*5+f,score:ratio}})});mark(best.slot);if(best.slot!==candidate){candidate=best.slot;holdStart=best.slot>=0?now:0;}else if(candidate>=0&&now-holdStart>800){selectSlot(candidate);holdStart=now+999999;}}
  }
  function hook(){if(!window.hands||window.__EDITHSpiderDoubleHook)return;window.__EDITHSpiderDoubleHook=true;const original=window.hands.onResults;window.hands.onResults=function(results){try{if(typeof original==='function')original(results)}catch(e){}try{process(results)}catch(e){}}}
  window.EDITHSpiderGestureMenu={open,close,render,process,data:MODES};
  window.edithOpenSpiderGestureMenu=open;window.edithCloseSpiderGestureMenu=close;
  const watcher=setInterval(()=>{hook();if(window.hands&&window.hands.onResults&&window.__EDITHSpiderDoubleHook)clearInterval(watcher)},250);
})();
