#!/usr/bin/env python3
"""EDITH PS5 Local Network Bridge.

Local-only helper for the EDITH PS5 UI. It can:
- check that the bridge is alive;
- ping a PS5 on the same LAN;
- open/close the official PS Remote Play application.

It does NOT log in, handle passwords, or bypass PlayStation authentication.
"""
import json, os, platform, re, subprocess, threading, time, urllib.parse, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOST = "127.0.0.1"
PORT = 8765
CONFIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "edith_ps5_lan_config.json")
_lock = threading.Lock()


def load_config():
    try:
        with open(CONFIG, "r", encoding="utf-8") as f:
            d = json.load(f)
            return {"ps5_ip": str(d.get("ps5_ip", "")).strip()}
    except Exception:
        return {"ps5_ip": ""}


def save_config(ip):
    with _lock:
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump({"ps5_ip": ip}, f, ensure_ascii=False, indent=2)


def valid_ip(ip):
    return bool(re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", ip)) and all(0 <= int(x) <= 255 for x in ip.split('.'))


def ping_host(ip):
    if not valid_ip(ip):
        return False
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", "1000", ip]
    else:
        cmd = ["ping", "-c", "1", "-W", "1", ip]
    try:
        p = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
        return p.returncode == 0
    except Exception:
        return False


def process_names():
    system = platform.system().lower()
    try:
        if system == "windows":
            out = subprocess.check_output(["tasklist"], text=True, stderr=subprocess.DEVNULL, timeout=3)
        else:
            out = subprocess.check_output(["ps", "-ax"], text=True, stderr=subprocess.DEVNULL, timeout=3)
        return out.lower()
    except Exception:
        return ""


def remote_play_running():
    out = process_names()
    needles = ["ps remote play", "remoteplay", "psremoteplay"]
    return any(n in out for n in needles)


def launch_remote_play():
    system = platform.system().lower()
    try:
        if system == "darwin":
            # Official Sony app if installed.
            subprocess.Popen(["open", "-a", "PS Remote Play"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        if system == "windows":
            # Ask Windows to resolve the installed app/registered shortcut.
            subprocess.Popen(["cmd", "/c", "start", "", "psremoteplay:"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        if system == "linux":
            # No universal official Linux Remote Play client. Open local launcher if present.
            candidates = [
                os.path.expanduser("~/.local/bin/psremoteplay"),
                os.path.expanduser("~/Applications/PS Remote Play.app"),
            ]
            for c in candidates:
                if os.path.exists(c):
                    subprocess.Popen([c], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return True
            return False
    except Exception:
        return False
    return False


def quit_remote_play():
    system = platform.system().lower()
    try:
        if system == "darwin":
            subprocess.run(["osascript", "-e", 'tell application "PS Remote Play" to quit'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
            return True
        if system == "windows":
            subprocess.run(["taskkill", "/IM", "RemotePlay.exe", "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
            return True
        if system == "linux":
            subprocess.run(["pkill", "-f", "psremoteplay"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
            return True
    except Exception:
        return False
    return False


def status():
    cfg = load_config()
    ip = cfg.get("ps5_ip", "")
    reachable = ping_host(ip) if ip else False
    return {
        "ok": True,
        "bridgeRunning": True,
        "host": HOST,
        "port": PORT,
        "ps5Ip": ip,
        "ps5Reachable": reachable,
        "remotePlayRunning": remote_play_running(),
        "platform": platform.system(),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "EDITH-PS5-LAN/1.0"
    def _send(self, code, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path == "/status":
            return self._send(200, status())
        if u.path == "/test-ps5":
            cfg = load_config(); ip = cfg.get("ps5_ip", "")
            return self._send(200, {"ok": True, "ps5Ip": ip, "ps5Reachable": ping_host(ip) if ip else False})
        if u.path == "/set-ps5":
            ip = str(q.get("ip", [""])[0]).strip()
            if not valid_ip(ip):
                return self._send(400, {"ok": False, "error": "invalid_ip"})
            save_config(ip)
            return self._send(200, {"ok": True, **status()})
        if u.path == "/launch":
            ok = launch_remote_play()
            return self._send(200, {"ok": ok, "remotePlayRunning": remote_play_running()})
        return self._send(404, {"ok": False, "error": "not_found"})

    def do_POST(self):
        if self.path == "/quit":
            ok = quit_remote_play()
            return self._send(200, {"ok": ok, "remotePlayRunning": remote_play_running()})
        return self._send(404, {"ok": False, "error": "not_found"})

    def log_message(self, fmt, *args):
        print("[EDITH PS5] " + fmt % args)


def main():
    print(f"EDITH PS5 LAN Bridge → http://{HOST}:{PORT}")
    print("Local only. Set the PS5 IP from the EDITH PS5 panel.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()

if __name__ == "__main__":
    main()
