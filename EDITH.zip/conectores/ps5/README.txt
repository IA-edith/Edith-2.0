EDITH PS5 — PUENTE DE RED LOCAL

Este paquete añade un puente local para comprobar la PS5 en la misma red y lanzar la aplicación oficial PS Remote Play.

NO hace magia de vídeo/control directo por LAN: la PS5 no expone a una página web un flujo de vídeo/control genérico. Para vídeo dentro de EDITH usa PS Remote Play o una capturadora HDMI UVC.

Uso:
- macOS: ./iniciar_puente_ps5.command
- Windows: iniciar_puente_ps5.bat
- Linux: python3 edith_ps5_lan_bridge.py

Luego, en MODO PS5, introduce la IP local de la PS5 y pulsa PROBAR RED LOCAL.
