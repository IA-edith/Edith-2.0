EDITH — PUENTE PS5 EN RED LOCAL

1. Conecta la PS5 y el ordenador al mismo router (Wi‑Fi o Ethernet).
2. En PS5: Ajustes → Red → Ver estado de conexión → Dirección IP.
3. Inicia el puente:
   - macOS: doble clic en iniciar_puente_ps5.command (puede requerir permiso para ejecutarlo)
   - Windows: doble clic en iniciar_puente_ps5.bat
   - Linux: python3 edith_ps5_lan_bridge.py
4. Abre EDITH y entra en MODO PS5.
5. Introduce la IP de la PS5 en PUENTE LAN y pulsa PROBAR RED.

El puente solo verifica la conectividad local (ping) y puede abrir/cerrar la aplicación oficial PS Remote Play.
No obtiene contraseñas, no almacena credenciales y no intenta saltarse la autenticación de PlayStation.

IMPORTANTE:
La red local por sí sola no proporciona a un navegador un vídeo/control directo de la PS5. Para vídeo dentro del HUD se puede usar PS Remote Play o, de forma más directa, una capturadora HDMI UVC.
