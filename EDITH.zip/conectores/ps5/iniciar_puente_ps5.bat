@echo off
python edith_ps5_lan_bridge.py
pause
