from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser, json, urllib.request

ROOT=Path(__file__).resolve().parent

def ollama_reply(payload):
    try:
        req=urllib.request.Request('http://127.0.0.1:11434/api/chat', data=json.dumps({
            'model':'llama3.2', 'stream':False,
            'messages':[
                {'role':'system','content':'Eres EDITH, una asistente de voz en español. Responde de forma natural, útil y breve. No inventes acceso a hardware ni acciones que no se hayan ejecutado.'},
                *[{'role':m.get('role','user'),'content':m.get('content','')} for m in payload.get('history',[])][-12:],
                {'role':'user','content':payload.get('message','')}
            ]
        }).encode(),headers={'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=45) as r:
            data=json.loads(r.read().decode('utf-8'))
        return data.get('message',{}).get('content','').strip()
    except Exception:
        return None

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def do_POST(self):
        if self.path!='/api/local-ai':
            self.send_error(404); return
        try:
            n=int(self.headers.get('Content-Length','0')); payload=json.loads(self.rfile.read(n) or b'{}')
            reply=ollama_reply(payload)
            body=json.dumps({'reply':reply or '', 'provider':'ollama' if reply else 'none'},ensure_ascii=False).encode('utf-8')
            self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
        except Exception as e:
            body=json.dumps({'reply':'','error':str(e)},ensure_ascii=False).encode('utf-8')
            self.send_response(500); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)

server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
url='http://127.0.0.1:8765/EDITH.html'
print('EDITH OFFLINE:',url)
print('IA LOCAL OPCIONAL: instala Ollama + un modelo (por ejemplo llama3.2) para respuestas abiertas sin Internet.')
try: webbrowser.open(url)
except Exception: pass
try: server.serve_forever()
except KeyboardInterrupt: pass
finally: server.server_close()
