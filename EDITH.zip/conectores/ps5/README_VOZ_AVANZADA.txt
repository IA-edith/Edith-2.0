EDITH · VOZ AVANZADA OFFLINE

1. Ejecuta iniciar_edith_offline.py.
2. Pulsa ESCUCHAR o di/usa el comando de conversación avanzada cuando el reconocimiento del navegador esté disponible.
3. EDITH habla mediante SpeechSynthesis del sistema.
4. Para que EDITH pueda contestar preguntas abiertas sin Internet, instala Ollama en el equipo y un modelo local. El servidor busca automáticamente Ollama en 127.0.0.1:11434 y usa el modelo llama3.2.
5. Sin un modelo local, EDITH mantiene respuestas internas, calculadora básica y comandos de la interfaz, pero no puede generar conocimiento abierto ilimitado offline.

Privacidad: el modo local-ai apunta únicamente a localhost. No se incrusta ninguna API key.
