#!/bin/bash
cd "$(dirname "$0")"
python3 edith_ps5_lan_bridge.py
