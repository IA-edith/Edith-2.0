EDITH — CEREBRO COMPLETO

La arquitectura ahora separa:
1. Voz -> transcripción
2. Cerebro OpenAI -> comprensión/razonamiento
3. Herramientas -> acciones reales y seguras
4. Memoria -> hechos + historial
5. Planificador -> planes/tareas
6. Visión -> cámara/OCR/objetos + visión OpenAI
7. Web -> búsqueda actualizada mediante herramienta de OpenAI
8. Perfil -> personalidad, idioma y preferencias
9. Automatización -> recordatorios e informe diario
10. Integraciones -> PC, GPS y Home Assistant opcional

IDEAS ADICIONALES PREPARADAS/ESCALABLES
- plugins/skills registrables por voz
- auditoría de herramientas
- copia de seguridad de memoria
- niveles de autorización para ampliar acciones
- búsqueda local de archivos
- laboratorio/impresión 2D/3D existente
- modo estudio existente
- modos holográficos existentes
- diagnóstico automático

COMANDOS DE EJEMPLO
"EDITH, recuerda que prefiero respuestas cortas."
"EDITH, busca en Internet las noticias de hoy."
"EDITH, analiza lo que estoy viendo."
"EDITH, lee el texto de la cámara."
"EDITH, ¿dónde estoy?"
"EDITH, crea un plan para terminar mi proyecto."
"EDITH, añade una tarea: probar el modo Venom."
"EDITH, recuérdame estudiar en 3600 segundos."
"EDITH, abre YouTube."
"EDITH, haz un diagnóstico del sistema."
"EDITH, dame mi informe diario."
"EDITH, cambia a personalidad técnica."
"EDITH, ¿qué recuerdas de mi proyecto?"

La interfaz continúa siendo voz-first y no requiere botones.
