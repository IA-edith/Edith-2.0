#!/bin/bash
cd "$(dirname "$0")"
python3 ps5_bridge.py
