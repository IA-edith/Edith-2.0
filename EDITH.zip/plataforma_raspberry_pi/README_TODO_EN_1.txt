EDITH COMPLETA — TODO EN 1

Este paquete reúne la interfaz principal EDITH en un solo proyecto, sin demos y sin modo VR.
Incluye voz automática, cámara, modos, estudio, gaming, Fortnite, Nintendo, PS5, Xbox, Hacker,
y álbumes y las integraciones de compartir/puentes incluidas en EDITH.html.

ARCHIVOS PRINCIPALES
- EDITH.html — interfaz completa
- ps5_bridge.py — puente local para PS5 / PS Remote Play
- INICIAR_PS5_BRIDGE.command — inicio rápido del puente en macOS
- README_ESTUDIO.txt

NOTAS
- La voz puede requerir permiso de micrófono del navegador.
- Compartir Nintendo/Xbox usa las APIs de captura de pantalla/ventana del navegador o una capturadora HDMI.
- PS5 usa el puente local y PS Remote Play oficial; EDITH no almacena contraseñas.
