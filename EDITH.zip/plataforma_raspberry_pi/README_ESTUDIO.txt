EDITH · CENTRO DE ESTUDIO COMPLETO

Incluye los modos académicos:
- Matemáticas
- Biología
- Física
- Español
- Inglés
- Francés
- Química
- Política
- Psicología

Control principal por voz. El centro se abre con "EDITH, activa modo estudio" y cada materia puede abrirse por nombre.
El modo Matemáticas conserva la calculadora científica previa.
