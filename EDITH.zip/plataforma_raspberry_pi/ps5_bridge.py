#!/usr/bin/env python3
import json, os, platform, subprocess
from http.server import BaseHTTPRequestHandler, HTTPServer

HOST='127.0.0.1'
PORT=8765


def run(cmd):
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
    except Exception:
        return None


def remote_play_running():
    system=platform.system()
    if system=='Darwin':
        r=run(['pgrep','-f','RemotePlay'])
        return bool(r and r.returncode==0 and r.stdout.strip())
    if system=='Windows':
        r=run(['tasklist','/FI','IMAGENAME eq RemotePlay.exe'])
        return bool(r and 'RemotePlay.exe' in r.stdout)
    r=run(['pgrep','-f','RemotePlay'])
    return bool(r and r.returncode==0 and r.stdout.strip())


def launch_remote_play():
    system=platform.system()
    if system=='Darwin':
        r=run(['open','-a','PS Remote Play'])
        return bool(r and r.returncode==0)
    if system=='Windows':
        candidates=[
            os.path.expandvars(r'%ProgramFiles%\\Sony\\PS Remote Play\\RemotePlay.exe'),
            os.path.expandvars(r'%ProgramFiles(x86)%\\Sony\\PS Remote Play\\RemotePlay.exe'),
        ]
        for path in candidates:
            if os.path.exists(path):
                try:
                    subprocess.Popen([path])
                    return True
                except Exception:
                    pass
        r=run(['cmd','/c','start','','RemotePlay.exe'])
        return bool(r and r.returncode==0)
    return False


def quit_remote_play():
    system=platform.system()
    if system=='Darwin':
        r=run(['osascript','-e','tell application "PS Remote Play" to quit'])
        return bool(r and r.returncode==0)
    if system=='Windows':
        r=run(['taskkill','/IM','RemotePlay.exe','/F'])
        return bool(r and r.returncode==0)
    r=run(['pkill','-f','RemotePlay'])
    return bool(r and r.returncode==0)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def headers(self):
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        self.send_header('Cache-Control','no-store')

    def send_json(self, data, code=200):
        body=json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.headers()
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204); self.headers(); self.end_headers()

    def do_GET(self):
        if self.path.startswith('/status'):
            running=remote_play_running()
            self.send_json({
                'bridge': True,
                'host': HOST,
                'port': PORT,
                'platform': platform.system(),
                'remotePlayRunning': running,
                'state': 'REMOTE PLAY ABIERTO' if running else 'PUENTE LISTO',
                'note': 'La conexión de la consola la gestiona PS Remote Play oficial.'
            })
            return
        if self.path.startswith('/launch'):
            ok=launch_remote_play()
            self.send_json({'ok':ok,'remotePlayRunning':remote_play_running(),'message':'PS Remote Play iniciado' if ok else 'No se pudo abrir PS Remote Play'})
            return
        self.send_json({'bridge':True,'service':'EDITH PS5 Bridge'})

    def do_POST(self):
        if self.path.startswith('/quit'):
            ok=quit_remote_play()
            self.send_json({'ok':ok,'remotePlayRunning':remote_play_running()})
            return
        self.send_json({'ok':False,'error':'Ruta no disponible'},404)


if __name__=='__main__':
    print(f'EDITH PS5 Bridge activo en http://{HOST}:{PORT}')
    print('Abre EDITH y di: "EDITH, conecta PS5"')
    print('La cuenta y el emparejamiento se realizan en PS Remote Play oficial.')
    HTTPServer((HOST,PORT),Handler).serve_forever()
