#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 edith_pi_server.py > edith_pi_server.log 2>&1 &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT
sleep 1
BROWSER=""
for b in chromium chromium-browser google-chrome; do
  if command -v "$b" >/dev/null 2>&1; then BROWSER="$b"; break; fi
done
if [[ -n "$BROWSER" ]]; then
  exec "$BROWSER" --autoplay-policy=no-user-gesture-required --enable-features=WebSpeechAPI --app="http://127.0.0.1:8765/edith"
else
  echo "Servidor EDITH activo: http://127.0.0.1:8765/edith"
  wait "$SERVER_PID"
fi
