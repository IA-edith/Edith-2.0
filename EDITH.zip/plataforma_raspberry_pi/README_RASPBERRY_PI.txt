EDITH — VERSION RASPBERRY PI
============================

Esta versión conserva el proyecto unificado de EDITH sin modo VR y añade una base local para Raspberry Pi.

INICIO RAPIDO
-------------
1. Instala Raspberry Pi OS 64-bit y Chromium.
2. Abre una terminal en esta carpeta.
3. Ejecuta:
   ./iniciar_edith_pi.sh
4. EDITH se abre en modo aplicación en http://127.0.0.1:8765/edith

FUNCIONES PI
------------
- Cámara del Raspberry Pi o cámara USB desde el navegador.
- Micrófono mediante permisos del navegador.
- Voz automática cuando el navegador la permite.
- Panel local de estado del sistema: temperatura CPU, memoria y disco.
- Todos los modos del paquete EDITH.
- Nintendo, PS5, Xbox y Hacker activables por voz, sin VR.
- PS5 mantiene el flujo por navegador/Remote Play; la cuenta y autenticación se realizan en los servicios oficiales de Sony.

NOTAS
-----
- Raspberry Pi no ejecuta aquí software propietario de consola dentro de EDITH.
- La conexión real de consolas depende de Remote Play, capturadora HDMI o el método oficial correspondiente.
- La voz del navegador puede variar según la versión de Chromium y los permisos del sistema.
- No se incluyen claves API en este paquete.
