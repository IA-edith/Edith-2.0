#!/usr/bin/env python3
import json, os, platform, shutil, subprocess, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

HOST = '0.0.0.0'
PORT = 8765
ROOT = os.path.dirname(os.path.abspath(__file__))


def run(cmd, timeout=5):
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    except Exception:
        return None


def cpu_temp_c():
    for p in ('/sys/class/thermal/thermal_zone0/temp', '/sys/class/hwmon/hwmon0/temp1_input'):
        try:
            with open(p, 'r', encoding='utf-8') as f:
                return round(int(f.read().strip()) / 1000.0, 1)
        except Exception:
            pass
    return None


def memory_info():
    total = available = None
    try:
        with open('/proc/meminfo', 'r', encoding='utf-8') as f:
            vals = {}
            for line in f:
                k, v = line.split(':', 1)
                vals[k] = int(v.strip().split()[0]) * 1024
            total = vals.get('MemTotal')
            available = vals.get('MemAvailable')
    except Exception:
        return {'total': None, 'available': None, 'usedPercent': None}
    if total and available is not None:
        used = total - available
        return {'total': total, 'available': available, 'usedPercent': round(used / total * 100, 1)}
    return {'total': total, 'available': available, 'usedPercent': None}


def disk_info():
    try:
        u = shutil.disk_usage(ROOT)
        return {'total': u.total, 'free': u.free, 'usedPercent': round((u.total-u.free)/u.total*100,1)}
    except Exception:
        return {'total': None, 'free': None, 'usedPercent': None}


def remote_play_running():
    r = run(['pgrep', '-f', 'RemotePlay'])
    return bool(r and r.returncode == 0 and r.stdout.strip())


def launch_remote_play():
    # On Raspberry Pi, the official Sony PS Remote Play desktop app is not
    # generally available. We open the browser page instead.
    url = 'https://remoteplay.dl.playstation.net/remoteplay/'
    for browser in ('chromium', 'chromium-browser', 'google-chrome'):
        if shutil.which(browser):
            try:
                subprocess.Popen([browser, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True, 'PS Remote Play abierto en el navegador.'
            except Exception:
                pass
    return False, 'No se encontró Chromium/Chrome.'


def open_url(url):
    for browser in ('chromium', 'chromium-browser', 'google-chrome'):
        if shutil.which(browser):
            try:
                subprocess.Popen([browser, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except Exception:
                pass
    return False


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def send_json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/status':
            self.send_json({
                'bridge': True,
                'service': 'EDITH Raspberry Pi Bridge',
                'platform': platform.platform(),
                'hostname': platform.node(),
                'cpuTemperatureC': cpu_temp_c(),
                'memory': memory_info(),
                'disk': disk_info(),
                'remotePlayRunning': remote_play_running(),
                'time': time.time(),
            })
            return
        if path == '/ps5/launch':
            ok, message = launch_remote_play()
            self.send_json({'ok': ok, 'message': message})
            return
        if path == '/system/restart-browser':
            ok = open_url('http://127.0.0.1:8765/edith')
            self.send_json({'ok': ok})
            return
        if path == '/':
            self.send_response(302)
            self.send_header('Location', '/edith')
            self.end_headers()
            return
        if path == '/edith' or path == '/EDITH_PI.html':
            try:
                with open(os.path.join(ROOT, 'EDITH_PI.html'), 'rb') as f:
                    data = f.read()
            except OSError:
                self.send_json({'ok': False, 'error': 'EDITH_PI.html no encontrado'}, 404)
                return
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        self.send_json({'ok': False, 'error': 'Ruta no disponible'}, 404)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == '/ps5/quit':
            self.send_json({'ok': True, 'message': 'En Raspberry Pi la desconexión se realiza desde PS Remote Play.'})
            return
        self.send_json({'ok': False, 'error': 'Ruta no disponible'}, 404)


if __name__ == '__main__':
    print(f'EDITH Raspberry Pi Bridge en http://127.0.0.1:{PORT}/edith')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
