EDITH — Sistemas 36–135
Integración unificada sobre la versión anterior.
Incluye panel EDITH CORE, inteligencia adaptativa, visión/voz, GPS, evolución, XP, misiones, logros,
Gaming, laboratorio, Cosmos, educación, idiomas, herramientas, archivo, conexiones, seguridad,
modos especiales, personalización, rutinas, módulos, perfil/backup, multiplataforma y Self Status.
Los módulos sensibles permanecen limitados a funciones locales y seguras.
