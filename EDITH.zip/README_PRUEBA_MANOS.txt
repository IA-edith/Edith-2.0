EDITH DEFINITIVA — PRUEBA MANOS

1) Abre EDITH.html mediante un servidor HTTP:
   python3 -m http.server 8080
2) Abre:
   http://127.0.0.1:8080/EDITH.html

Corrección incluida:
- El cargador ya no puede quedarse congelado en 0% por un módulo opcional.
- Los errores de módulos opcionales no bloquean el arranque.
- Los controles principales se presentan en el menú de manos/palmas.
- Se ocultan los botones tradicionales de menú principal.
- Se incluye un lanzador para Raspberry Pi y un ejemplo de servicio systemd.

Nota:
El reconocimiento real de manos necesita que el motor/modelo de visión correspondiente esté presente. Esta versión no inventa un modelo offline que no esté empaquetado.
