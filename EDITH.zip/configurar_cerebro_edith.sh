#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
ENV_FILE="$BASE/edith.env"
if [[ ! -f "$ENV_FILE" ]]; then cp "$BASE/edith.env.example" "$ENV_FILE"; fi
printf "Clave API de OpenAI (no se mostrará): "
read -r -s KEY
echo
if [[ -z "$KEY" ]]; then echo "ERROR: no se recibió una clave."; exit 1; fi
python3 - "$ENV_FILE" "$KEY" <<'PY'
import sys
p,key=sys.argv[1:]
lines=[]
for line in open(p,encoding='utf-8'):
    if line.startswith('OPENAI_API_KEY='): lines.append('OPENAI_API_KEY='+key+'\n')
    else: lines.append(line)
open(p,'w',encoding='utf-8').writelines(lines)
PY
chmod 600 "$ENV_FILE"
cat > "$BASE/edith_start_unificado.sh" <<'LAUNCH'
#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE"
if [[ -f "$BASE/edith.env" ]]; then set -a; source "$BASE/edith.env"; set +a; fi
export EDITH_ROOT="$BASE"
exec python3 "$BASE/edith_ultra_brain.py"
LAUNCH
chmod +x "$BASE/edith_start_unificado.sh"
# Make the standard ultra launcher use the persistent env and unified server.
cat > iniciar_edith_ultra.sh <<'EOF'
#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
exec "$BASE/edith_start_unificado.sh"
