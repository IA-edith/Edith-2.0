EDITH

Esta versión crea una arquitectura de IA local más potente, no una copia del modelo propietario de OpenAI.

- UI EDITH + voz + memoria
- Servidor local en 127.0.0.1:8765
- Ollama como motor local compatible
- Contexto de conversación (hasta 20 mensajes enviados al modelo)
- Memoria persistente local en edith_memory.json
- Estado del cerebro visible en la interfaz
- Sin API keys
- Puede funcionar sin Wi‑Fi una vez que el modelo local ya esté instalado

Arranque:
  python3 edith_ultra_brain.py
  y abre http://127.0.0.1:8765/EDITH.html

Modelo por defecto: llama3.2
Puedes cambiarlo:
  EDITH_MODEL=qwen3:8b python3 edith_ultra_brain.py

Para una conversación realmente abierta, el equipo debe tener un modelo local instalado. El navegador por sí solo no puede contener un modelo grande de este nivel.


CEREBRO OPENAI: esta versión usa OpenAI Responses API mediante OPENAI_API_KEY. La clave se mantiene exclusivamente en el servidor local. Modelo configurable con EDITH_OPENAI_MODEL.
