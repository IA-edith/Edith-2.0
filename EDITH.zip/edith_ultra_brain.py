#!/usr/bin/env python3
import json, os, urllib.request, urllib.error, time, re, subprocess, threading, datetime, platform, webbrowser
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from edith_print_lab import make_3d, make_2d, OUT
from edith_all_ideas import action as all_ideas_action

ROOT=os.path.dirname(os.path.abspath(__file__))
DATA=os.path.join(ROOT,'edith_data')
os.makedirs(DATA,exist_ok=True)
MEM=os.path.join(DATA,'edith_memory.json')
SCHEDULE_FILE=os.path.join(DATA,'schedule.json')
PROFILE_FILE=os.path.join(DATA,'profile.json')
PLANS_FILE=os.path.join(DATA,'plans.json')
TASKS_FILE=os.path.join(DATA,'tasks.json')
LOCATION_FILE=os.path.join(DATA,'location.json')
AUDIT_FILE=os.path.join(DATA,'audit.jsonl')
OPENAI_API_KEY=os.environ.get('OPENAI_API_KEY','').strip()
OPENAI_URL='https://api.openai.com/v1/responses'
MODEL=os.environ.get('EDITH_OPENAI_MODEL','gpt-5.6-sol')

SYSTEM='''Eres EDITH, una asistente de IA local. Responde siempre en español salvo que el usuario pida otro idioma. Sé inteligente, clara, precisa y natural. Mantén el contexto de la conversación, analiza cada petición antes de responder y usa la memoria persistente cuando sea relevante. No inventes capacidades ni hechos. Si una acción requiere hardware externo, explica el límite. Puedes ayudar con programación, matemáticas, ciencia, estudio, planificación, escritura, análisis y conversación. No afirmes tener acceso a sistemas que no estén conectados. Tu interfaz puede tener módulos ficticios de Spider-Man/Homecoming/Far From Home, pero trátalos como ficción/simulación.'''

def load_mem():
    try:
        with open(MEM,'r',encoding='utf-8') as f:return json.load(f)
    except:return {'facts':{},'history':[]}

def save_mem(m):
    json_save(MEM,m) if 'json_save' in globals() else None
    if 'json_save' not in globals():
        with open(MEM,'w',encoding='utf-8') as f:json.dump(m,f,ensure_ascii=False,indent=2)
    try:
        with open(os.path.join(DATA,'edith_memory_backup.json'),'w',encoding='utf-8') as f:json.dump(m,f,ensure_ascii=False,indent=2)
    except: pass

def json_load(path, default):
    try:
        with open(path,'r',encoding='utf-8') as f:return json.load(f)
    except:return default

def json_save(path, value):
    tmp=path+'.tmp'
    with open(tmp,'w',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2)
    os.replace(tmp,path)

def audit(event, data=None):
    try:
        with open(AUDIT_FILE,'a',encoding='utf-8') as f:
            f.write(json.dumps({'ts':time.time(),'event':event,'data':data or {}},ensure_ascii=False)+'\n')
    except: pass

def get_profile():
    return json_load(PROFILE_FILE, {'name':'','personality':'EQUILIBRADA','conversation':'NATURAL','language':'es','active_mode':'EDITH'})

def set_profile(data):
    cur=get_profile(); cur.update({k:v for k,v in data.items() if v is not None}); json_save(PROFILE_FILE,cur); return cur

def get_plans(): return json_load(PLANS_FILE,[])
def save_plans(x): json_save(PLANS_FILE,x)
def get_tasks(): return json_load(TASKS_FILE,[])
def save_tasks(x): json_save(TASKS_FILE,x)
def get_location(): return json_load(LOCATION_FILE,{})
def save_location(x): json_save(LOCATION_FILE,x)

def system_status():
    return {
        'os':platform.platform(), 'python':platform.python_version(), 'model':MODEL,
        'openai':bool(OPENAI_API_KEY), 'memory':True,
        'internet_search':True, 'voice':'browser/sistema',
        'profile':get_profile(), 'location_available':bool(get_location())
    }

def local_search(query, limit=8):
    """Busca nombres/contenido textual dentro de la carpeta de EDITH."""
    q=[w.lower() for w in str(query).split() if len(w)>2]
    hits=[]
    for base,dirs,files in os.walk(ROOT):
        dirs[:]=[d for d in dirs if d not in {'.git','node_modules','__pycache__','edith_data'}]
        for fn in files:
            path=os.path.join(base,fn)
            score=sum(w in fn.lower() for w in q)
            if score:
                hits.append({'path':os.path.relpath(path,ROOT),'score':score})
                continue
            if len(hits)>=limit*3: continue
            try:
                if os.path.getsize(path)>1024*1024: continue
                with open(path,'r',encoding='utf-8',errors='ignore') as f:
                    txt=f.read(120000).lower()
                score=sum(w in txt for w in q)
                if score: hits.append({'path':os.path.relpath(path,ROOT),'score':score})
            except: pass
    return sorted(hits,key=lambda x:x['score'],reverse=True)[:limit]

def tool_defs():
    return [
      {'type':'web_search'},
      {'type':'function','name':'remember_fact','description':'Guarda un dato importante a largo plazo. Úsalo cuando el usuario diga recuerda, guarda, memoriza o exprese una preferencia que deba conservarse.','parameters':{'type':'object','properties':{'fact':{'type':'string'}},'required':['fact'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'get_memory','description':'Consulta la memoria persistente de EDITH cuando la pregunta dependa de algo que el usuario dijo anteriormente.','parameters':{'type':'object','properties':{'query':{'type':'string'}},'required':['query'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'create_reminder','description':'Crea un recordatorio local. delay_seconds indica cuánto esperar desde ahora.','parameters':{'type':'object','properties':{'text':{'type':'string'},'delay_seconds':{'type':'number'},'repeat_seconds':{'type':'number'}},'required':['text','delay_seconds'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'list_reminders','description':'Lista los recordatorios programados.','parameters':{'type':'object','properties':{},'additionalProperties':False},'strict':True},
      {'type':'function','name':'create_plan','description':'Crea un plan con objetivo y pasos para un proyecto o tarea.','parameters':{'type':'object','properties':{'title':{'type':'string'},'goal':{'type':'string'},'steps':{'type':'array','items':{'type':'string'}}},'required':['title','goal','steps'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'add_task','description':'Añade una tarea a la lista de EDITH.','parameters':{'type':'object','properties':{'text':{'type':'string'},'plan':{'type':'string'}},'required':['text'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'complete_task','description':'Marca una tarea por texto como completada.','parameters':{'type':'object','properties':{'text':{'type':'string'}},'required':['text'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'set_profile','description':'Cambia preferencias de EDITH, como personalidad, idioma, estilo o modo de conversación.','parameters':{'type':'object','properties':{'name':{'type':'string'},'personality':{'type':'string'},'conversation':{'type':'string'},'language':{'type':'string'},'active_mode':{'type':'string'}},'additionalProperties':False},'strict':True},
      {'type':'function','name':'get_system_status','description':'Comprueba el estado del cerebro, memoria, voz, Internet y sistema.','parameters':{'type':'object','properties':{},'additionalProperties':False},'strict':True},
      {'type':'function','name':'open_pc_app','description':'Abre una aplicación permitida en el ordenador.','parameters':{'type':'object','properties':{'name':{'type':'string'}},'required':['name'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'open_url','description':'Abre una URL web solicitada por el usuario.','parameters':{'type':'object','properties':{'url':{'type':'string'}},'required':['url'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'home_control','description':'Controla un dispositivo domótico si Home Assistant está configurado. Si no está configurado devuelve disponibilidad.','parameters':{'type':'object','properties':{'entity_id':{'type':'string'},'action':{'type':'string'}},'required':['entity_id','action'],'additionalProperties':False},'strict':True},
      {'type':'function','name':'get_location','description':'Obtiene la última ubicación GPS compartida por el navegador.','parameters':{'type':'object','properties':{},'additionalProperties':False},'strict':True},
      {'type':'function','name':'search_local_files','description':'Busca archivos o documentación dentro de la carpeta de EDITH.','parameters':{'type':'object','properties':{'query':{'type':'string'}},'required':['query'],'additionalProperties':False},'strict':True},
    ]

def execute_tool(name,args):
    args=args or {}; audit('tool_call',{'name':name,'args':args})
    if name=='remember_fact':
        fact=str(args.get('fact','')).strip(); m=load_mem(); facts=m.setdefault('facts',{}); facts['tool_'+str(int(time.time()*1000))]=fact; m['updated_at']=time.time(); save_mem(m); return {'ok':True,'saved':fact}
    if name=='get_memory':
        m=load_mem(); q=str(args.get('query','')).lower(); facts=list(m.get('facts',{}).values());
        hits=[x for x in facts if not q or any(w in str(x).lower() for w in q.split() if len(w)>3)]
        return {'facts':hits[-40:],'history':m.get('history',[])[-30:]}
    if name=='create_reminder':
        text=str(args.get('text','Recordatorio')); delay=float(args.get('delay_seconds',0)); item={'id':str(int(time.time()*1000)),'text':text,'ts':time.time()+max(0,delay),'enabled':True,'repeat_seconds':float(args.get('repeat_seconds',0) or 0)}; items=load_schedule(); items.append(item); save_schedule(items); return {'ok':True,'item':item}
    if name=='list_reminders': return {'reminders':load_schedule()}
    if name=='create_plan':
        plans=get_plans(); item={'id':str(int(time.time()*1000)),'title':args['title'],'goal':args['goal'],'steps':[{'text':x,'done':False} for x in args['steps']],'created_at':time.time()}; plans.append(item); save_plans(plans); return {'ok':True,'plan':item}
    if name=='add_task':
        tasks=get_tasks(); item={'id':str(int(time.time()*1000)),'text':args['text'],'plan':args.get('plan',''),'done':False,'created_at':time.time()}; tasks.append(item); save_tasks(tasks); return {'ok':True,'task':item}
    if name=='complete_task':
        q=str(args['text']).lower(); tasks=get_tasks(); found=None
        for t in tasks:
            if not t.get('done') and q in t.get('text','').lower(): t['done']=True; t['completed_at']=time.time(); found=t; break
        save_tasks(tasks); return {'ok':bool(found),'task':found}
    if name=='set_profile': return {'ok':True,'profile':set_profile(args)}
    if name=='get_system_status': return system_status()
    if name=='open_pc_app': return safe_pc_action('open_app',{'name':args['name']})
    if name=='open_url': return safe_pc_action('open_url',{'url':args['url']})
    if name=='home_control': return home_control(args['entity_id'],args['action'])
    if name=='get_location': return get_location() or {'ok':False,'message':'No hay ubicación compartida'}
    if name=='search_local_files': return {'results':local_search(args.get('query',''))}
    return {'ok':False,'error':'Herramienta desconocida'}

def home_control(entity_id, action):
    base=os.environ.get('EDITH_HOME_ASSISTANT_URL','').rstrip('/')
    token=os.environ.get('EDITH_HOME_ASSISTANT_TOKEN','').strip()
    if not base or not token: return {'ok':False,'available':False,'message':'Home Assistant no está configurado.'}
    # Only expose simple allowlisted services.
    services={'turn_on':'homeassistant/turn_on','turn_off':'homeassistant/turn_off','toggle':'homeassistant/toggle'}
    if action not in services: return {'ok':False,'error':'Acción domótica no permitida'}
    data=json.dumps({'entity_id':entity_id}).encode(); req=urllib.request.Request(base+'/api/services/'+services[action],data=data,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=10) as r:return {'ok':True,'status':r.status}
    except Exception as e:return {'ok':False,'error':str(e)}

def call_openai(message, history, image_data=None):
    idea_state = all_ideas_action('state', {})
    if idea_state.get('local'):
        raise RuntimeError('EDITH está en modo local: no se permite enviar datos a Internet/OpenAI.')
    """Cerebro OpenAI con memoria, herramientas, web search y planificación."""
    if not OPENAI_API_KEY: raise RuntimeError('Falta OPENAI_API_KEY en las variables de entorno.')
    m=load_mem(); profile=get_profile(); plans=get_plans(); tasks=get_tasks(); location=get_location()
    context=[]
    facts=m.get('facts',{})
    if facts: context.append({'role':'developer','content':'Memoria persistente: '+json.dumps(facts,ensure_ascii=False)})
    context.append({'role':'developer','content':'Perfil EDITH: '+json.dumps(profile,ensure_ascii=False)})
    context.append({'role':'developer','content':'Planes activos: '+json.dumps(plans[-10:],ensure_ascii=False)+'\nTareas: '+json.dumps(tasks[-30:],ensure_ascii=False)+'\nUbicación disponible: '+json.dumps(location,ensure_ascii=False)})
    for item in (history or [])[-50:]:
        role=item.get('role'); content=str(item.get('content','')).strip()
        if role in ('user','assistant') and content: context.append({'role':role,'content':content})
    if image_data:
        content=[{'type':'input_text','text':message},{'type':'input_image','image_url':image_data}]
        context.append({'role':'user','content':content})
    else: context.append({'role':'user','content':message})

    instructions=SYSTEM+"""\nEres el cerebro central de EDITH. Puedes usar herramientas para recordar, planificar, consultar Internet, gestionar tareas, recordatorios, perfil, ubicación, ordenador y domótica.\nDecide cuándo una herramienta es necesaria. No inventes resultados de herramientas. Puedes buscar en Internet cuando la pregunta requiera información actual. Usa la memoria cuando ayude. Razona internamente, pero nunca muestres cadenas de pensamiento privadas. Si una acción del sistema no está disponible, dilo claramente y ofrece la alternativa. Responde en español salvo petición distinta."""
    payload={'model':MODEL,'instructions':instructions,'input':context,'reasoning':{'effort':'high'},'tools':([] if idea_state.get('emergency') else tool_defs()),'tool_choice':'auto','store':True}
    if image_data: payload['include']=['web_search_call.action.sources']

    for _ in range(6):
        data=json.dumps(payload,ensure_ascii=False).encode(); req=urllib.request.Request(OPENAI_URL,data=data,headers={'Content-Type':'application/json','Authorization':'Bearer '+OPENAI_API_KEY},method='POST')
        with urllib.request.urlopen(req,timeout=120) as r:j=json.load(r)
        calls=[x for x in j.get('output',[]) if x.get('type')=='function_call']
        if not calls:
            text=j.get('output_text') or ''.join(c.get('text','') for x in j.get('output',[]) for c in x.get('content',[]) if c.get('type')=='output_text')
            if not text: raise RuntimeError('OpenAI devolvió una respuesta vacía.')
            return text
        outputs=[]
        for c in calls:
            try: args=json.loads(c.get('arguments') or '{}')
            except: args={}
            result=execute_tool(c.get('name',''),args)
            outputs.append({'type':'function_call_output','call_id':c.get('call_id'),'output':json.dumps(result,ensure_ascii=False)})
        payload={'model':MODEL,'previous_response_id':j.get('id'),'input':outputs,'tools':([] if idea_state.get('emergency') else tool_defs()),'tool_choice':'auto','store':True,'instructions':instructions}
    raise RuntimeError('Límite de herramientas alcanzado')

def remember(message, reply):
    """Guarda conversación y memoria a largo plazo de EDITH."""
    m=load_mem()
    h=m.setdefault('history',[])
    h.extend([
        {'role':'user','content':message,'ts':time.time()},
        {'role':'assistant','content':reply,'ts':time.time()}
    ])
    m['history']=h[-500:]

    facts=m.setdefault('facts',{})
    text=str(message).strip()

    # Memoria explícita.
    mm=re.search(r'(?:recuerda|recuérdame|recuerdame|recuerda que|guarda que|memoriza|anota)\s+(.+)',text,re.I)
    if mm:
        item=mm.group(1).strip()
        if item:
            facts['mem_'+str(int(time.time()*1000))]=item

    # Preferencias y datos conversacionales expresados naturalmente.
    patterns=[
        r'\b(?:me gusta|prefiero|no me gusta|odio|mi nombre es|llámame|llamame|mi proyecto es|quiero que|mi objetivo es)\s+(.+)',
        r'\b(?:soy|estoy aprendiendo|trabajo en|estoy haciendo)\s+(.+)'
    ]
    for pat in patterns:
        pm=re.search(pat,text,re.I)
        if pm:
            item=pm.group(0).strip()
            facts['context_'+str(int(time.time()*1000))]=item
            break

    # Metadatos para poder saber cuándo fue actualizada.
    m['memory_version']=2
    m['updated_at']=time.time()
    save_mem(m)

def load_schedule():
    try:
        with open(SCHEDULE_FILE,'r',encoding='utf-8') as f:return json.load(f)
    except:return []

def save_schedule(items):
    with open(SCHEDULE_FILE,'w',encoding='utf-8') as f:json.dump(items,f,ensure_ascii=False,indent=2)

def notify(title, text):
    try:
        if platform.system()=='Darwin':
            subprocess.run(['osascript','-e',f'display notification {json.dumps(text)} with title {json.dumps(title)}'],timeout=5)
        elif platform.system()=='Windows':
            # no external dependency; best-effort PowerShell toast fallback
            ps=f'[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;'
            ps+=f'$xml=[Windows.Data.Xml.Dom.XmlDocument]::new();$xml.LoadXml(\'<toast><visual><binding template="ToastGeneric"><text>{title}</text><text>{text}</text></binding></visual></toast>\');'
            ps+='[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("EDITH").Show([Windows.UI.Notifications.ToastNotification]::new($xml))'
            subprocess.run(['powershell','-NoProfile','-Command',ps],timeout=8)
        else:
            subprocess.run(['notify-send',title,text],timeout=5)
    except Exception as e: print('notify:',e)

def scheduler_loop():
    while True:
        try:
            items=load_schedule(); changed=False; now=time.time()
            for item in items:
                if item.get('enabled',True) and item.get('ts',0)<=now:
                    notify('EDITH',item.get('text','Recordatorio'))
                    
                    if float(item.get('repeat_seconds',0) or 0)>0:
                        item['ts']=now+float(item['repeat_seconds']); item['enabled']=True
                    else:
                        item['enabled']=False
                    changed=True
            if changed: save_schedule(items)
        except Exception as e: print('scheduler:',e)
        time.sleep(1)

threading.Thread(target=scheduler_loop,daemon=True).start()

def safe_pc_action(action, args=None):
    args=args or {}
    if action=='open_url':
        url=str(args.get('url','')).strip()
        if not re.match(r'^https?://',url): return {'ok':False,'error':'URL no permitida'}
        webbrowser.open(url); return {'ok':True}
    if action=='open_app':
        name=str(args.get('name','')).lower().strip()
        allowed={'calculadora':['Calculator','calc.exe','gnome-calculator'],'notas':['Notes','notepad.exe'],'terminal':['Terminal','cmd.exe'],'calendario':['Calendar'],'navegador':['Safari','chrome','msedge.exe']}
        candidates=allowed.get(name)
        if not candidates:return {'ok':False,'error':'Aplicación no permitida'}
        if platform.system()=='Darwin':
            subprocess.Popen(['open','-a',candidates[0]])
        elif platform.system()=='Windows':
            subprocess.Popen(candidates[1] if len(candidates)>1 else candidates[0],shell=True)
        else: subprocess.Popen([candidates[-1]])
        return {'ok':True}
    return {'ok':False,'error':'Acción no permitida'}

class Handler(SimpleHTTPRequestHandler):
    def _json(self, code, obj):
        raw=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_POST(self):
        path=urlparse(self.path).path
        try:
            n=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(n) or b'{}')
            if path=='/api/all-ideas':
                return self._json(200,all_ideas_action(str(body.get('op','state')),body.get('data',{})))
            if path=='/api/local-ai':
                msg=str(body.get('message','')).strip(); hist=body.get('history',[])
                if not msg: return self._json(400,{'error':'message requerido'})
                try:
                    reply=call_openai(msg,hist,body.get('image_data'))
                    if not reply: raise RuntimeError('respuesta vacía')
                    if not all_ideas_action('state',{}).get('private'): remember(msg,reply)
                    return self._json(200,{'reply':reply,'provider':'openai','model':MODEL,'private':bool(all_ideas_action('state',{}).get('private'))})
                except Exception as e:
                    return self._json(503,{'error':'No se pudo conectar con el cerebro OpenAI','detail':str(e),'hint':'Configura OPENAI_API_KEY en el servidor/Raspberry.'})
            if path=='/api/location':
                loc={'latitude':float(body.get('latitude')),'longitude':float(body.get('longitude')),'accuracy':body.get('accuracy'),'timestamp':time.time()}; save_location(loc); return self._json(200,{'ok':True,'location':loc})
            if path=='/api/profile': return self._json(200,{'ok':True,'profile':set_profile(body)})
            if path=='/api/plan':
                plans=get_plans(); item={'id':str(int(time.time()*1000)),'title':str(body.get('title','Plan')),'goal':str(body.get('goal','')),'steps':[{'text':str(x),'done':False} for x in body.get('steps',[])],'created_at':time.time()}; plans.append(item); save_plans(plans); return self._json(200,{'ok':True,'plan':item})
            if path=='/api/task':
                tasks=get_tasks(); item={'id':str(int(time.time()*1000)),'text':str(body.get('text','')),'plan':str(body.get('plan','')),'done':False,'created_at':time.time()}; tasks.append(item); save_tasks(tasks); return self._json(200,{'ok':True,'task':item})
            if path=='/api/vision':
                image=str(body.get('image_data','')).strip(); prompt=str(body.get('prompt','Analiza esta imagen.')).strip();
                if not image:return self._json(400,{'ok':False,'error':'image_data requerida'})
                try:return self._json(200,{'ok':True,'reply':call_openai(prompt,body.get('history',[]),image)})
                except Exception as e:return self._json(503,{'ok':False,'error':str(e)})
            if path=='/api/schedule':
                text=str(body.get('text','Recordatorio')).strip(); delay=float(body.get('delay_seconds',0) or 0)
                when=float(body.get('timestamp',0) or 0) or (time.time()+max(0,delay))
                item={'id':str(int(time.time()*1000)),'text':text,'ts':when,'enabled':True,'repeat_seconds':float(body.get('repeat_seconds',0) or 0)}
                items=load_schedule(); items.append(item); save_schedule(items)
                return self._json(200,{'ok':True,'item':item})
            if path=='/api/pc-action':
                return self._json(200,safe_pc_action(str(body.get('action','')),body.get('args',{})))
            if path=='/api/print3d':
                desc=str(body.get('description','')).strip()
                if not desc:return self._json(400,{'ok':False,'error':'description requerida'})
                try:
                    f=make_3d(desc); return self._json(200,{'ok':True,'file':'edith_prints/'+f.name,'format':f.suffix.lstrip('.'),'message':'Modelo generado'})
                except Exception as e:return self._json(500,{'ok':False,'error':str(e)})
            if path=='/api/print2d':
                desc=str(body.get('description','')).strip()
                if not desc:return self._json(400,{'ok':False,'error':'description requerida'})
                try:
                    f=make_2d(desc); return self._json(200,{'ok':True,'file':'edith_prints/'+f.name,'format':f.suffix.lstrip('.'),'message':'Diseño 2D generado'})
                except Exception as e:return self._json(500,{'ok':False,'error':str(e)})
            self.send_error(404); return
        except Exception as e:self._json(400,{'error':str(e)})
    def do_DELETE(self):
        if self.path=='/api/memory':
            save_mem({'facts':{},'history':[],'memory_version':2,'updated_at':time.time()}); audit('memory_clear'); return self._json(200,{'ok':True})
        self.send_error(404)

    def do_GET(self):
        if self.path=='/api/all-ideas': return self._json(200,all_ideas_action('state',{}))
        if self.path=='/api/ideas-stats': return self._json(200,all_ideas_action('stats',{}))
        if self.path=='/api/brain-status':
            ok=bool(OPENAI_API_KEY)
            return self._json(200,{'ok':ok,'model':MODEL,'provider':'openai','detail':'OpenAI configurado' if ok else 'Falta OPENAI_API_KEY'})
        if self.path=='/api/memory': return self._json(200,load_mem())
        if self.path=='/api/schedule': return self._json(200,load_schedule())
        if self.path=='/api/profile': return self._json(200,get_profile())
        if self.path=='/api/plans': return self._json(200,get_plans())
        if self.path=='/api/tasks': return self._json(200,get_tasks())
        if self.path=='/api/location': return self._json(200,get_location())
        if self.path=='/api/system-status': return self._json(200,system_status())
        return super().do_GET()

os.chdir(ROOT)
print(f'EDITH OpenAI Brain: http://127.0.0.1:8765  | modelo: {MODEL}  | API key: {"OK" if OPENAI_API_KEY else "FALTA"}')
ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()


# Diccionario local de EDITH: base pequeña y ampliable sin Internet.
EDITH_DICTIONARY = {
    "algoritmo": "Conjunto ordenado de pasos para resolver un problema.",
    "interfaz": "Medio por el que una persona interactúa con un sistema.",
    "latencia": "Tiempo que tarda una información en viajar y recibir respuesta.",
    "holograma": "Imagen o interfaz visual con apariencia tridimensional.",
    "diagnóstico": "Proceso de identificar el estado o la causa de un problema.",
    "autónomo": "Que puede funcionar o actuar sin intervención constante.",
}

def dictionary_lookup(word):
    """Consulta el diccionario local; devuelve None si no existe."""
    return EDITH_DICTIONARY.get(str(word).strip().lower())
