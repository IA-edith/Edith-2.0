EDITH — FAR FROM HOME · MODO SIN WIFI

IMPORTANTE:
La primera vez debes abrir EDITH con internet para que el Service Worker descargue y guarde localmente los modelos de visión. Después puedes desconectar el Wi‑Fi y usar EDITH sin internet.

1. Ejecuta iniciar_edith_offline.py
2. Abre EDITH y espera a que aparezca “CACHÉ OFFLINE LISTO”.
3. La cámara y el reconocimiento de manos siguen funcionando localmente.
4. GPS funciona sin internet para coordenadas; los mapas/noticias externas no se actualizan sin conexión y quedan en modo local/fallback.
5. No se envían claves de API desde este paquete.

En macOS/Windows/Linux con Python 3:
    python iniciar_edith_offline.py

Mantén la carpeta completa; no borres edith-offline-sw.js.


VOZ: EDITH incluye salida de voz local mediante SpeechSynthesis del navegador. El reconocimiento de voz usa el motor disponible del navegador; su disponibilidad sin Internet depende del sistema/navegador.
