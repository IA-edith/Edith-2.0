EDITH — DICCIONARIO INTERNO OFFLINE

Incluye una base local de palabras y un sistema de aprendizaje persistente.

Funciones JavaScript:
- window.edithDictionaryLookup("palabra")
- window.edithDictionaryExplain("palabra")
- window.edithDictionaryLearn("palabra", "definición", {idioma:"es"})
- window.edithDictionaryWords()

Las palabras aprendidas se guardan en localStorage como EDITH_DICTIONARY_V1.
No necesita Internet para consultar las palabras que ya están almacenadas.

LABORATORIO DE IMPRESIÓN
- Voz: “EDITH, crea un modelo 3D de un cubo de 30 x 30 x 10 mm”.
- Voz: “EDITH, crea un diseño 2D de una estrella”.
- La interfaz genera archivos en edith_prints/.
- STL se puede abrir en un slicer. SVG/PNG son diseños 2D imprimibles.
- Para modelos 3D arbitrarios, EDITH puede usar Ollama local para generar OpenSCAD y OpenSCAD para convertirlo a STL si está instalado.
