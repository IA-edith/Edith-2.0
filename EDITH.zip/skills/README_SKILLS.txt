EDITH SKILLS / PLUGINS

Cada habilidad nueva puede registrarse desde JavaScript sin crear botones:

window.EDITHRegisterPlugin('nombre', async function(texto){
  // acción
}, ['alias 1','alias 2']);

El cerebro central puede usar herramientas del servidor para acciones reales.
Para nuevas integraciones, mantener siempre:
- lista blanca de acciones;
- confirmación para acciones irreversibles;
- registro de auditoría;
- sin API keys en el navegador.
