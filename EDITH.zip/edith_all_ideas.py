import os, json, time, re, platform, shutil, subprocess, hashlib, secrets, datetime, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'edith_data'; DATA.mkdir(exist_ok=True)
IDEAS_FILE=DATA/'ideas_state.json'; PROJECTS=DATA/'projects.json'; PERMS=DATA/'permissions.json'; STATS=DATA/'usage_stats.json'; NOTIFS=DATA/'notifications.json'; KNOW=DATA/'knowledge.json'

def load(p,d):
    try:return json.loads(Path(p).read_text(encoding='utf-8'))
    except:return d

def save(p,v):
    p=Path(p); tmp=p.with_suffix(p.suffix+'.tmp'); tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8'); os.replace(tmp,p)

def now(): return time.time()
def audit(event, data=None):
    try:
        with open(DATA/'audit.jsonl','a',encoding='utf-8') as f:f.write(json.dumps({'ts':now(),'event':event,'data':data or {}},ensure_ascii=False)+'\n')
    except:pass

def state():
    return load(IDEAS_FILE, {'private':False,'local':False,'emergency':False,'active_project':'default','permission_level':2,'installed_skills':[],'translation':{'target':'es'},'stats':{}})

def update_state(**kw):
    s=state(); s.update(kw); save(IDEAS_FILE,s); return s

def bump(action):
    s=load(STATS,{'total':0,'actions':{},'first_seen':now()}); s['total']+=1; s['actions'][action]=s['actions'].get(action,0)+1; s['last_action']=action; s['last_ts']=now(); save(STATS,s); audit(action); return s

def projects(): return load(PROJECTS,[{'id':'default','name':'EDITH','description':'Proyecto principal','created_at':now()}])
def notifications(): return load(NOTIFS,[])

def add_notification(title,text,level='info'):
    n=notifications(); item={'id':secrets.token_hex(6),'title':title,'text':text,'level':level,'ts':now(),'read':False}; n.append(item); save(NOTIFS,n); return item

def create_project(name,description=''):
    p=projects(); pid=re.sub(r'[^a-z0-9_-]+','-',name.lower()).strip('-') or secrets.token_hex(4); pid=pid+'-'+secrets.token_hex(2); item={'id':pid,'name':name,'description':description,'created_at':now(),'memory':[]}; p.append(item); save(PROJECTS,p); update_state(active_project=pid); return item

def add_project_memory(text, ttl='permanent'):
    p=projects(); s=state(); pid=s.get('active_project','default');
    for x in p:
        if x['id']==pid:
            exp=None if ttl=='permanent' else now()+({'temporary':3600,'weekly':7*86400,'daily':86400}.get(ttl,30*86400)); x.setdefault('memory',[]).append({'text':text,'ttl':ttl,'expires_at':exp,'ts':now()}); break
    save(PROJECTS,p); return True

def expire_memory():
    p=projects(); changed=False
    for x in p:
        old=x.get('memory',[]); x['memory']=[m for m in old if not m.get('expires_at') or m['expires_at']>now()]; changed|=len(old)!=len(x['memory'])
    if changed:save(PROJECTS,p)

def permission_ok(level=2): return state().get('permission_level',2)>=level

def system_metrics():
    loadavg=None
    try: loadavg=os.getloadavg()
    except: pass
    du=shutil.disk_usage(ROOT)
    return {'platform':platform.platform(),'python':platform.python_version(),'cpu_count':os.cpu_count(),'loadavg':loadavg,'disk_free':du.free,'disk_total':du.total,'memory_note':'Disponible según plataforma; usa psutil si está instalado.','uptime_seconds':time.time()-psutil_boot(),'network':network_ok()}

def psutil_boot():
    try:
        import psutil; return psutil.boot_time()
    except:return time.time()

def network_ok():
    try:
        urllib.request.urlopen('https://example.com',timeout=2); return True
    except:return False

def self_test():
    tests=[]
    for name,fn in [('memoria',lambda: load(IDEAS_FILE,{}) is not None),('proyectos',lambda:isinstance(projects(),list)),('filesystem',lambda:ROOT.exists()),('python',lambda:bool(platform.python_version()))]:
        try:tests.append({'name':name,'ok':bool(fn())})
        except Exception as e:tests.append({'name':name,'ok':False,'error':str(e)})
    return {'ok':all(x['ok'] for x in tests),'tests':tests}

def backup_encrypted(password=''):
    src=DATA/'edith_memory.json'; out=DATA/'edith_memory_backup.enc';
    if not src.exists(): return {'ok':False,'error':'No existe memoria todavía'}
    if not password: return {'ok':False,'error':'Se requiere una contraseña para cifrar la copia'}
    # AES-256-GCM via OpenSSL when available; password never persisted.
    try:
        p=subprocess.run(['openssl','enc','-aes-256-cbc','-pbkdf2','-salt','-pass','stdin','-in',str(src),'-out',str(out)],input=password.encode(),capture_output=True,timeout=15)
        if p.returncode!=0: raise RuntimeError(p.stderr.decode(errors='ignore'))
        return {'ok':True,'file':str(out.relative_to(ROOT)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
    except Exception as e:return {'ok':False,'error':str(e)}

def local_knowledge(query):
    q=[w for w in re.findall(r'\w+',query.lower()) if len(w)>2]; hits=[]
    for path in ROOT.rglob('*'):
        if not path.is_file() or 'edith_data' in path.parts or path.stat().st_size>2_000_000: continue
        try:t=path.read_text(encoding='utf-8',errors='ignore').lower()
        except:continue
        score=sum(t.count(w)+path.name.lower().count(w)*3 for w in q)
        if score:hits.append({'path':str(path.relative_to(ROOT)),'score':score})
    return sorted(hits,key=lambda x:x['score'],reverse=True)[:12]

def generate_report(title,content,fmt='html'):
    safe=re.sub(r'[^a-zA-Z0-9_-]+','_',title)[:70] or 'informe';
    if fmt=='html':
        out=DATA/(safe+'.html'); out.write_text('<!doctype html><meta charset="utf-8"><title>'+title+'</title><h1>'+title+'</h1><pre>'+content.replace('&','&amp;').replace('<','&lt;')+'</pre>',encoding='utf-8'); return str(out.relative_to(ROOT))
    try:
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        out=DATA/(safe+'.pdf'); doc=SimpleDocTemplate(str(out)); st=getSampleStyleSheet(); story=[Paragraph(title,st['Title'])]
        for part in content.split('\n'): story += [Paragraph(part.replace('&','&amp;'),st['BodyText']),Spacer(1,6)]
        doc.build(story); return str(out.relative_to(ROOT))
    except Exception as e:return {'error':str(e)}

def diagram(code,title='EDITH Diagram'):
    safe=re.sub(r'[^a-zA-Z0-9_-]+','_',title)[:60] or 'diagram'; out=DATA/(safe+'.html');
    html='<!doctype html><meta charset="utf-8"><script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script><div class="mermaid">'+code+'</div><script>mermaid.initialize({startOnLoad:true});</script>'
    out.write_text(html,encoding='utf-8'); return str(out.relative_to(ROOT))

def gpio(action,pin,value=None):
    allowed={17,18,22,23,24,25}; pin=int(pin)
    if pin not in allowed:return {'ok':False,'error':'GPIO fuera de la lista blanca'}
    try:
        from gpiozero import LED
        led=LED(pin)
        if action in ('on','turn_on'):led.on()
        elif action in ('off','turn_off'):led.off()
        elif action=='toggle':led.toggle()
        else:return {'ok':False,'error':'Acción GPIO no permitida'}
        return {'ok':True,'pin':pin,'action':action}
    except Exception as e:return {'ok':False,'error':'GPIO no disponible: '+str(e)}

def action(op, data=None):
    data=data or {}; bump(op); expire_memory()
    if op=='state': return state()
    if op=='private': return update_state(private=bool(data.get('enabled',True)))
    if op=='local': return update_state(local=bool(data.get('enabled',True)))
    if op=='emergency': return update_state(emergency=bool(data.get('enabled',True)),permission_level=0 if data.get('enabled',True) else state().get('permission_level',2))
    if op=='permission': return update_state(permission_level=max(0,min(5,int(data.get('level',2)))))
    if op=='project_create': return create_project(str(data.get('name','Proyecto')),str(data.get('description','')))
    if op=='project_use': return update_state(active_project=str(data.get('id','default')))
    if op=='project_memory': return {'ok':add_project_memory(str(data.get('text','')),str(data.get('ttl','permanent')))}
    if op=='project_list': return projects()
    if op=='stats': return load(STATS,{'total':0,'actions':{}})
    if op=='metrics': return system_metrics()
    if op=='self_test': return self_test()
    if op=='notifications': return notifications()
    if op=='notify': return add_notification(str(data.get('title','EDITH')),str(data.get('text','')),str(data.get('level','info')))
    if op=='knowledge': return local_knowledge(str(data.get('query','')))
    if op=='report': return {'file':generate_report(str(data.get('title','Informe EDITH')),str(data.get('content','')),str(data.get('format','html')))}
    if op=='diagram': return {'file':diagram(str(data.get('code','graph TD; A[EDITH]-->B[IA]')),str(data.get('title','EDITH Diagram')))}
    if op=='backup': return backup_encrypted(str(data.get('password','')))
    if op=='gpio': return gpio(str(data.get('action','off')),data.get('pin',17),data.get('value'))
    if op=='skill_install':
        s=state(); name=str(data.get('name','skill')); arr=s.setdefault('installed_skills',[]); 
        if name not in arr:arr.append(name); save(IDEAS_FILE,s)
        return {'ok':True,'installed':arr}
    if op=='calendar_add':
        f=DATA/'calendar.json'; a=load(f,[]); item={'id':secrets.token_hex(6),'title':data.get('title','Evento'),'start':data.get('start'),'end':data.get('end'),'ts':now()};a.append(item);save(f,a);return item
    if op=='calendar_list': return load(DATA/'calendar.json',[])
    if op=='email_draft':
        return {'ok':True,'draft':{'to':data.get('to',''),'subject':data.get('subject',''),'body':data.get('body',''),'status':'draft_only'}}
    if op=='music':
        return {'ok':True,'action':data.get('action','pause'),'note':'Control de música preparado; la aplicación reproductora debe exponer una API o controles del sistema.'}
    if op=='update_check':
        return {'ok':True,'git_available':shutil.which('git') is not None,'message':'Comprobación segura disponible; las actualizaciones no se aplican automáticamente.'}
    if op=='sync': return {'ok':False,'configured':False,'message':'Sincronización opcional preparada; requiere un destino autorizado.'}
    if op=='translate': return {'ok':True,'source':data.get('text',''),'target':data.get('target','es'),'note':'La traducción lingüística avanzada se delega al cerebro OpenAI.'}
    return {'ok':False,'error':'Operación no implementada'}
